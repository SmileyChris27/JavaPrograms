import java.util.*;
public class FeetToInches2{
   
   public static void main(String args[]){
   
   double feet;
   
   Scanner input =new Scanner(System.in);
	
	System.out.print("Enter amount of Feet:");
   
	feet = input.nextDouble();
   
   double inches = feet * 12;
   
   System.out.println(inches + "Inches");
   }
}
   