import java.util.Scanner;
public class IntegerDivision
{
	public static void main (String[] args)
	{
	double A, B;
	
	Scanner input=new Scanner(System.in);
	
	System.out.print("Enter First Integer");

	A=input.nextDouble();
	
	System.out.print("Enter Second Integer");

	B=input.nextDouble();
	
	System.out.println("The Quotient:"+ A/B);
	}
}