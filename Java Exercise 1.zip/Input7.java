// This program is used for values //
import java.util.*;
public class Input7
{
	public static void main(String args[])
	{
	
		int value1, value2 ;
		Scanner input =new Scanner(System.in);			
		System.out.print("Enter a number1:");
		value1 = input.nextInt();
		System.out.print("Enter a number2:");
		value2 = input.nextInt();
		
		System.out.println("Sum is: " + (value1+value2) );
		System.out.println("Diffrence is: " + (value1-value2) );
		System.out.println("Product is: " + (value1*value2) );

		}
}