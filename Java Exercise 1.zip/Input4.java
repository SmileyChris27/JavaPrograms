import java.util.*;
public class Input4
{
	public static void main(String args[])
	{
	
		int value ;
		Scanner input =new Scanner(System.in);
		System.out.print("Enter an integer:");
		value = input.nextInt();
		System.out.println("Value typed is " + (value+1) );
	}
}
	