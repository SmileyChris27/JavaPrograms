// This program is used to find a certain value type //
import java.util.*;
public class Input6
{
	public static void main(String args[])
	{
	
		int value ;
		Scanner input =new Scanner(System.in);			
		System.out.print("Enter an integer:");
		value = input.nextInt();
		System.out.println("Value typed is " + (value-5) );
		System.out.println("Value typed is " + (value+5) );
		System.out.println("Value typed is " + (value-5) );
		System.out.println("Value typed is " + (value+40) );
		

		
		

		
	}
}