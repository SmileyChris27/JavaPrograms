import java.util.* ;
class Input
{
	public static void main (String args[])
	{
	
		int value;
		Scanner input =new Scanner(System.in);
		System.out.print("Enter an integer:");
		value = input.nextInt();
		System.out.printIn("Value typed is " + value );
	}
}
	