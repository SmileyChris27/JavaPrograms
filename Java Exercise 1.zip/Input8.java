// This program is used for values /
import java.util.*;
public class Input8
{
	public static void main(String args[])
	{
	
		int value1, value2 ;
		Scanner input =new Scanner(System.in);			
		System.out.print("Enter Midterm:");
		value1 = input.nextInt();
		System.out.print("Enter Final:");
		value2 = input.nextInt();
		
		System.out.println("Average is: " + (value1+value2)/2);


		}
}