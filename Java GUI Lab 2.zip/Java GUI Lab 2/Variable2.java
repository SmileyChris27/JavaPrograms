import javax.swing.*;

public class Variable2
{
	public static void main ( String [] args )
	{
		int x=10;
		JOptionPane.showMessageDialog(null, "x value is " + x ) ; //For GUI Use box //
		}
}